﻿using AutoMapper;
using ClinicManagementSystem.backend.Common.Exceptions.CustomExceptions;
using ClinicManagementSystem.backend.Common.Pagination;
using ClinicManagementSystem.backend.Features.Appointments.DTOs.Requests;
using ClinicManagementSystem.backend.Features.Appointments.DTOs.Responses;
using ClinicManagementSystem.backend.Features.Appointments.Interfaces;
using ClinicManagementSystem.backend.Features.Doctors.Interfaces;
using ClinicManagementSystem.backend.Features.Patients.Interfaces;
using ClinicManagementSystem.backend.Models;
using ClinicManagementSystem.backend.Persistence.Interfaces;

namespace ClinicManagementSystem.backend.Features.Appointments.Services
{
    public class AppointmentService : IAppointmentService
    {
        private readonly IAppointmentRepository _appointmentRepository;
        private readonly IDoctorRepository _doctorRepository;
        private readonly IDoctorWorkingHourRepository _workingHourRepository;
        private readonly IDoctorLeaveRepository _leaveRepository;
        private readonly IPatientRepository _patientRepository;
        private readonly IApplicationDbContext _context;
        private readonly IMapper _mapper;

        //Constructor
        public AppointmentService(
            IAppointmentRepository appointmentRepository,
            IDoctorRepository doctorRepository,
            IDoctorWorkingHourRepository workingHourRepository,
            IDoctorLeaveRepository leaveRepository,
            IPatientRepository patientRepository,
            IApplicationDbContext context,
            IMapper mapper)
        {
            _appointmentRepository = appointmentRepository;
            _doctorRepository = doctorRepository;
            _workingHourRepository = workingHourRepository;
            _leaveRepository = leaveRepository;
            _patientRepository = patientRepository;
            _context = context;
            _mapper = mapper;
        }

        /// <inheritdoc/>
        public async Task<AppointmentResponseDto> CreateAsync(CreateAppointmentRequestDto request, CancellationToken cancellationToken = default)
        {
            // Validate appointment date.
            ValidateAppointmentDate(request.AppointmentDate);

            // Validate appointment time.
            ValidateAppointmentTime(request.StartTime, request.EndTime);

            // Ensure doctor exists in the clinic or not .
            Doctor doctor = await ValidateDoctorExistsAsync(request.DoctorId, cancellationToken);

            int userId = _currentUserService.UserId;

            // Ensure patient exists.
            Patient patient = await ValidatePatientExistsAsync(request.PatientId, cancellationToken);



        }

        public async Task DeleteAsync(int appointmentId, CancellationToken cancellationToken = default)
        {
            throw new NotImplementedException();
        }

        public Task<bool> ExistsAsync(int appointmentId, CancellationToken cancellationToken = default)
        {
            throw new NotImplementedException();
        }

        public Task<PagedResult<AppointmentResponseDto>> GetAllAsync(PaginationParameters pagination, CancellationToken cancellationToken = default)
        {
            throw new NotImplementedException();
        }

        public Task<AppointmentDetailsResponseDto> GetByIdAsync(int appointmentId, CancellationToken cancellationToken = default)
        {
            throw new NotImplementedException();
        }

        public Task<AppointmentResponseDto> UpdateAsync(int appointmentId, UpdateAppointmentRequestDto request, CancellationToken cancellationToken = default)
        {
            throw new NotImplementedException();
        }

        //=================================================================================================

        //Private methods used for business validation


        /// <summary>
        /// Validates the appointment identifier.
        /// </summary>
        /// <param name="appointmentId">
        /// Appointment identifier.
        /// </param>
        /// <exception cref="BadRequestException">
        /// Thrown when the identifier is invalid.
        /// </exception>
        private static void ValidateAppointmentId(int appointmentId)
        {
            if (appointmentId <= 0)
            {
                throw new BadRequestException("Appointment ID must be greater than zero.");
            }
        }

        /// <summary>
        /// Retrieves an appointment or throws a <see cref="NotFoundException"/>.
        /// </summary>
        private async Task<Appointment> GetAppointmentOrThrowAsync(int appointmentId, CancellationToken cancellationToken)
        {
            Appointment? appointment = await _appointmentRepository.GetByIdAsync(appointmentId, cancellationToken);

            if (appointment is null)
            {
                throw new NotFoundException($"Appointment with ID '{appointmentId}' was not found.");

            }

            return appointment;
        }

        /// <summary>
        /// Validates the appointment date no in the past.
        /// </summary>
        private static void ValidateAppointmentDate(DateOnly appointmentDate)
        {
            if (appointmentDate < DateOnly.FromDateTime(DateTime.Today))
            {
                throw new BadRequestException("Appointment date cannot be in the past.");

            }
        }

        /// <summary>
        /// Validates appointment start and end times (End time must be greater than start time).
        /// </summary>
        private static void ValidateAppointmentTime(TimeOnly startTime, TimeOnly endTime)
        {
            if (endTime <= startTime)
            {
                throw new BadRequestException("End time must be greater than start time.");

            }
        }

        /// <summary>
        /// Validates that the doctor exists.
        /// </summary>
        private async Task<Doctor> ValidateDoctorExistsAsync(int doctorId, CancellationToken cancellationToken)
        {
            Doctor? doctor = await _doctorRepository.GetDoctorForAppointmentAsync(doctorId, cancellationToken);

            if (doctor is null)
            {
                throw new NotFoundException($"Doctor with ID '{doctorId}' was not found.");

            }

            return doctor;
        }

        /// <summary>
        /// Validates that the patient exists based on his profile.
        /// </summary>
        private async Task<Patient> ValidatePatientExistsAsync(int userId, CancellationToken cancellationToken)
        {
            Patient? patient = await _patientRepository.GetByUserIdAsync(userId, cancellationToken);

            if (patient is null)
            {
                throw new NotFoundException("Patient profile was not found.");
            }

            return patient;
        }

        /// <summary>
        /// Ensures that the doctor works during the requested period.
        /// </summary>
        private async Task ValidateDoctorWorkingHoursAsync(int doctorId, DateOnly appointmentDate, TimeOnly startTime, TimeOnly endTime, CancellationToken cancellationToken)

        {
            DayOfWeek day = appointmentDate.DayOfWeek;

            DoctorWorkingHour? workingHours = await _workingHourRepository.GetWorkingHoursAsync(doctorId, day, cancellationToken);

            if (workingHours is null)
            {
                throw new ConflictException("The doctor does not work on the selected day.");

            }

            if (startTime < workingHours.StartTime ||
                endTime > workingHours.EndTime)
            {
                throw new ConflictException("The appointment is outside the doctor's working hours.");

            }
        }

        /// <summary>
        /// Ensures that the doctor is not on leave.
        /// </summary>
        private async Task ValidateDoctorLeaveAsync(int doctorId, DateOnly appointmentDate, CancellationToken cancellationToken)
        {
            bool isOnLeave = await _leaveRepository.IsOnLeaveAsync(doctorId, appointmentDate, cancellationToken);

            if (isOnLeave)
            {
                throw new ConflictException("The doctor is on leave on the selected date.");

            }
        }


        /// <summary>
        /// Ensures that the doctor has no overlapping appointment.
        /// </summary>
        private async Task ValidateDoctorAppointmentConflictAsync(int doctorId, DateOnly appointmentDate, TimeOnly startTime, TimeOnly endTime, int? excludeAppointmentId, CancellationToken cancellationToken)

        {
            bool hasConflict = await _appointmentRepository.DoctorHasOverlappingAppointmentAsync(doctorId, appointmentDate, startTime, endTime, excludeAppointmentId, cancellationToken);

            if (hasConflict)
            {
                throw new ConflictException("The doctor already has another appointment during the selected time.");

            }
        }



        /// <summary>
        /// Ensures that the patient has no overlapping appointment.
        /// </summary>
        private async Task ValidatePatientAppointmentConflictAsync(int patientId, DateOnly appointmentDate, TimeOnly startTime, TimeOnly endTime, int? excludeAppointmentId, CancellationToken cancellationToken)
        {
            bool hasConflict = await _appointmentRepository.PatientHasOverlappingAppointmentAsync(patientId, appointmentDate, startTime, endTime, excludeAppointmentId, cancellationToken);

            if (hasConflict)
            {
                throw new ConflictException("The patient already has another appointment during the selected time.");

            }
        }


    }
}
